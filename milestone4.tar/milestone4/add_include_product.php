<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="main.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
</head>
<body>


<?php
session_start();
if($_SESSION['loggedin'] !== true){
    $_SESSION = array();
    session_destroy();
    header("location: ./welcome.html");
    exit;
}
if($_SESSION['manager'] === true){
    $return_url = "manage_function.php";
}
if($_SESSION['manager'] === false){
    $return_url = "sales_function.php";
}

if(empty($_POST["product_ID"])){
    $product_ID_err = "Please enter the product ID.";
} elseif(!ctype_digit($_POST[product_ID])){
    $product_ID_err = "Please enter a integer value。." ;
}else{
    $product_ID = $_POST["product_ID"];
}
if(empty($_POST["invoice_ID"])){
    $invoice_ID_err = "Please enter the invoice ID.";
} elseif(!ctype_digit($_POST[invoice_ID])){
    $invoice_ID_err = "Please enter a integer value" ;
}else{
    $invoice_ID = $_POST["invoice_ID"];
}

if($_POST["flagged"] )

?>


<?php
require_once('db_setup.php');
$sql = "USE yliu157_1;";
if ($conn->query($sql) === TRUE) {
   // echo "using Database tbiswas2_company";
} else {
   echo "Error using  database: " . $conn->error;
}

// Query:
$product_id = $__POST['Product_ID'];
$invoice_id = $_POST['Invoice_ID'];
$product_quantity = $__POST['Product_Quantity'];


$sql = "INSERT INTO Include_Product values ($product_id , $invoice_id, $product_quantity);";

$result = $conn->query($sql);

if ($result === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
//$stmt = $conn->prepare("Select * from Students Where Username like ?");
//$stmt->bind_param("s", $username);
//$result = $stmt->execute();
//$result = $conn->query($sql);
?>

<?php
$conn->close();
?>


<div class="topBar">
    <Header align = "middle" style = "color: White">
      <h1> Include_Product Manage System</h1>
      <h2> Add Include_Product</h2>
    </Header>

</div>

<div class="container" style="width: 400px;">
        <h1 align="middle">Add Include_Product</h1>
        <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="POST">
            <div class="form-group <?php echo (!empty($product_ID_err)) ? 'has-error' : ''; ?>">
                <label>Product ID</label>
                <input type="number" name="product_ID" class="form-control">
                <span class="help-block"><?php echo $product_ID_err; ?></span>
            </div>
            <div class="form-group <?php echo (!empty($invoice_ID_err)) ? 'has-error' : ''; ?>">
                <label>Invoice ID</label>
                <input type="number" name="invoice_ID" class="form-control">
                <span class="help-block"><?php echo $invoice_ID_err; ?></span>
            </div>
             <div class="form-group <?php echo (!empty($product_quantity_err)) ? 'has-error' : ''; ?>">
                <label>Product Quantity</label>
                <input type="number" name="product_quantity" class="form-control">
                <span class="help-block"><?php echo $product_quantity_err; ?></span>
            </div>
            <div class="form-group">
                <input align = "left" type="submit" class="btn btn-primary" style = "color: white; background-color: grey;" value="Login">
                <button align = "right" class="btn btn-primary" style = "color: white; background-color: grey;" onclick="location.href='~/<?php echo $return_url; ?>'" type="button">
                    Return</button>
            </div>
        </form>
</div>

</body>
</html>

