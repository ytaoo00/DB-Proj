<!DOCTYPE html>
<html>
<head>
    <title>Add include product</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="main.css">
</head>
<body>



<?php
require_once("db_setup.php");
session_start();
if($_SESSION['loggedin'] !== true){
    $_SESSION = array();
    session_destroy();
    header("location: ./welcome.html");
    exit;
}
if($_SESSION['manager'] === true){
    $return_url = "manage_function.php";
}
if($_SESSION['manager'] === false){
    $return_url = "sales_function.php";
}

$product_ID = $product_ID_err = "";
$product_price =$product_price_err = "";
$product_Name =$product_Name_err= "";
$db_message = "";
$showDiv = false; 

if($_SERVER["REQUEST_METHOD"] == "POST"){
if(empty($_POST["product_ID"])){
    $product_ID_err = "Please enter the prduct ID.";
} elseif(!ctype_digit($_POST[product_ID])){
    $product_ID_err= "Please enter a integer value。." ;
}else{
    $product_ID = $_POST["product_ID"];
}

$floatVal = floatval($product_price);
if(empty($_POST["product_price"])){
    $product_price_err = "Please enter the prduct ID.";
}elseif(!ctype_digit($_POST[product_price])){
	if($floatVal && intval($floatVal) != $floatVal){
		$product_price = $_POST["product_price"];
	}else{
	    $product_price_err= "Please enter a valid number." ;
	}
}else{
    $product_price = $_POST["product_price"];
}

if(empty($_POST["product_name"])){
    $product_name_err = "Please enter the prduct name.";
}else{
    $product_name = $_POST["product_name"];
}

$sql = "USE yliu157_1;";
if ($conn->query($sql) === TRUE) {
   // echo "using Database tbiswas2_company";
} else {
	 $showDiv = true;
   echo "Error using  database: " . $conn->error;
}

// Query:
$sql = "INSERT INTO Product values ($product_ID , $product_price , '$product_name');";

$result = $conn->query($sql);

if ($result === TRUE) {
	 $showDiv = true;
     $db_message =  "New record created successfully";
} else {
	 $showDiv = true;
     $db_message =  "Error: " . $sql . "<br>" . $conn->error;
}
//$stmt = $conn->prepare("Select * from Students Where Username like ?");
//$stmt->bind_param("s", $username);
//$result = $stmt->execute();
//$result = $conn->query($sql);

$conn->close();
}
?>


<div class="topBar">
    <Header align = "middle" style = "color: White">
      <h1> Product Manage System</h1>
      <h2> Add Product</h2>
    </Header>

</div>

<div class="container" style="width: 400px;">
        <h1 align="middle">Add Product</h1>
        <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="POST">
        <div <?php if ($showDiv===false){?> style="display:none" <?php } ?> class="form-group">
                <p style = "border: 3px solid black; color: red;"><?php echo $db_message?></p>
        </div>
            <div class="form-group <?php echo (!empty($product_ID_err)) ? 'has-error' : ''; ?>">
                <label>Product ID</label>
                <input type="number" name="product_ID" class="form-control">
                <span class="help-block"><?php echo $product_ID_err; ?></span>
            </div>
            <div class="form-group <?php echo (!empty($product_price_err)) ? 'has-error' : ''; ?>">
                <label>Product Price</label>
                <input type="number" name="product_price" class="form-control">
                <span class="help-block"><?php echo $product_price_err; ?></span>
            </div>
            <div class="form-group <?php echo (!empty($product_name_err)) ? 'has-error' : ''; ?>">
                <label>Product Name</label>
                <input type="text" name="product_name" class="form-control">
                <span class="help-block"><?php echo $product_name_err; ?></span>
            </div>
           <div class="form-group">
          <div class="row">
                    <div class="column">
                    <input type="submit" class="btn btn-primary" value="Submit">
                    </div>
                    <div class="column">
                    <button class="btn btn-primary" 
                        onclick="location.href='./<?php echo $return_url; ?>'" type="button">  
                        Return</button>  
                    </div>  
         </div>
        </form>
</div>

</body>
</html>

