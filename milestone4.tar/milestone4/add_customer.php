<!DOCTYPE html>
<html>
<head>
    <title>Add customer</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="main.css">
</head>
<body>



<?php
require_once("db_setup.php");
session_start();
if($_SESSION['loggedin'] !== true){
    $_SESSION = array();
    session_destroy();
    header("location: ./welcome.html");
    exit;
}
if($_SESSION['manager'] === true){
    $return_url = "manage_function.php";
}
if($_SESSION['manager'] === false){
    $return_url = "sales_function.php";
}

$cust_ID = $customer_ID_err = "";
$customer_first_name =$customer_first_name_err = "";
$customer_last_name =$customer_last_name_err= "";
$db_message = "";
$showDiv = false; 

if($_SERVER["REQUEST_METHOD"] == "POST"){
if(empty($_POST["customer_ID"])){
    $customer_ID_err = "Please enter the customer ID.";
} elseif(!ctype_digit($_POST[customer_ID])){
    $customer_ID_err= "Please enter a integer value." ;
}else{
    $customer_ID = $_POST["customer_ID"];
}

if(empty($_POST["customer_first_name"])){
    $customer_first_name_err = "Please enter the customer first name.";
}else{
    $customer_first_name = $_POST["customer_first_name"];
}

if(empty($_POST["customer_last_name"])){
    $customer_last_name_err = "Please enter the customer last name.";
}else{
    $customer_last_name = $_POST["customer_last_name"];
}

$customer_ID = $customer_ID_err='';
$customer_address =$customer_address_err='';
$customer_state =$customer_state_err='';
$customer_zip =$customer_zip_err='';
$customer_phone_number = $customer_phone_number_err='';


if(empty($_POST["customer_ID"])){
    $customer_ID_err = "Please enter the customer ID.";
} elseif(!ctype_digit($_POST[customer_ID])){
    $customer_ID_err = "Please enter a integer value." ;
}else{
    $customer_ID = $_POST["customer_ID"];
}

if(empty($_POST["customer_address"])){
    $customer_address_err = "Please enter the customer address.";
} else{
    $customer_address = $_POST["customer_address"];
}

if(empty($_POST["customer_zip"])){
    $customer_zip_err = "Please enter the customer zip.";
}elseif(!ctype_digit($_POST[customer_zip])){
    $customer_zip_err = "Please enter a integer value." ;
}else{
    $customer_zip = $_POST["customer_zip"];
}

if(empty($_POST["customer_state"])){
    $customer_state_err = "Please enter the customer state.";
} else{
    $customer_state = $_POST["customer_state"];
}

if(empty($_POST["customer_phone_number"])){
    $customer_phone_number_err = "Please enter the customer phone number.";
} elseif(!ctype_digit($_POST[customer_ID])){
    $customer_phone_number_err = "Please enter a integer value." ;
}else{
    $customer_phone_number = $_POST["customer_phone_number"];
}


$sql = "USE yliu157_1;";
if ($conn->query($sql) === TRUE) {
   // echo "using Database tbiswas2_company";
} else {
	$showDiv = true;
   echo "Error using  database: " . $conn->error;
}
  


$sql = "INSERT INTO Customer values ($customer_ID , '$customer_first_name' , '$customer_last_name');";

$result = $conn->query($sql);

$sql2 = "INSERT INTO Contact_Info values ($customer_ID , '$customer_address', '$customer_state', $customer_zip, $customer_phone_number);";

$result2 = $conn->query($sql2);

if ($result === TRUE && $result2 === TRUE) {
	$showDiv = true;
    $db_message = "New record created successfully";
} else {
	$showDiv = true;
    $db_message =  "Error: " . $sql . "<br>" . $conn->error;
}
//$stmt = $conn->prepare("Select * from Students Where Username like ?");
//$stmt->bind_param("s", $username);
//$result = $stmt->execute();
//$result = $conn->query($sql);


$conn->close();
}
?>


<div class="topBar">
    <Header align = "middle" style = "color: White">
      <h1> Customer Manage System</h1>
      <h2> Add Customer</h2>
    </Header>

</div>

<div class="container" style="width: 400px;">
  <h1 align="middle">Add Customer</h1>
  <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="POST">
    <div <?php if ($showDiv===false){?> style="display:none" <?php } ?> class="form-group">
      <p style="border: 3px solid black; color: red;"><?php echo $db_message?></p>
    </div>
    <div class="form-group <?php echo (!empty($customer_ID_err)) ? 'has-error' : ''; ?>">
      <label>Customer ID</label>
      <input type="number" name="customer_ID" class="form-control">
      <span class="help-block"><?php echo $customer_ID_err; ?></span>
    </div>
    <div class="form-group <?php echo (!empty($customer_first_name_err)) ? 'has-error' : ''; ?>">
      <label>Customer First Name</label>
      <input type="text" name="customer_first_name" class="form-control">
      <span class="help-block"><?php echo $customer_first_name_err; ?></span>
    </div>
    <div class="form-group <?php echo (!empty($customer_last_name_err)) ? 'has-error' : ''; ?>">
      <label>Customer Last Name</label>
      <input type="text" name="customer_last_name" class="form-control">
      <span class="help-block"><?php echo $customer_last_name_err; ?></span>
    </div>
    <div class="form-group <?php echo (!empty($customer_address_err)) ? 'has-error' : ''; ?>">
      <label>Customer Address</label>
      <input type="text" name="customer_address" class="form-control">
      <span class="help-block"><?php echo $customer_address_err; ?></span>
    </div>
    <div class="form-group <?php echo (!empty($customer_state_err)) ? 'has-error' : ''; ?>">
      <label>Customer State</label>
      <input type="text" name="customer_state" class="form-control">
      <span class="help-block"><?php echo $customer_state_err; ?></span>
    </div>
    <div class="form-group <?php echo (!empty($customer_zip_err)) ? 'has-error' : ''; ?>">
      <label>Customer Zip Code</label>
      <input type="number" name="customer_zip" class="form-control">
      <span class="help-block"><?php echo $customer_zip_err; ?></span>
    </div>
    <div class="form-group <?php echo (!empty($customer_phone_err)) ? 'has-error' : ''; ?>">
      <label>Customer Phone Number</label>
      <input type="number" name="customer_phone_number" class="form-control">
      <span class="help-block"><?php echo $customer_phone_err; ?></span>
    </div>
    <div class="form-group">
      <div class="row">
        <div class="column">
          <input type="submit" class="btn btn-primary" value="Submit">
        </div>
        <div class="column">
          <button class="btn btn-primary" onclick="location.href='./<?php echo $return_url; ?>'" type="button">
            Return</button>
        </div>
  </form>
</div>

</body>
</html>

