<!DOCTYPE html>
<html>
<head>

<link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" href="main.css">
</head>
<body>



<?php
require_once('db_setup.php');
session_start();
if($_SESSION['loggedin'] !== true){
    $_SESSION = array();
    session_destroy();
    header("location: ./welcome.html");
    exit;
}
$show_DIV = false;
if($_SESSION['manager'] === true){
    $show_DIV = true;
}

$sql = "USE yliu157_1";
if ($conn->query($sql) === TRUE) {
   // echo "using Database ";
} else {
   echo "Error using  database: " . $conn->error;
}
// Query:


//check which checkbox is selected 
if ($_POST["database"] === "invoice") {
    $to_view = "Invoice";
}
elseif($_POST["database"] === "product") {
    $to_view = "Product";
}
elseif($_POST["database"] === "customer") {
    $to_view = "Customer";
}
else {
    $to_view = "Contact_Info";
}
?>

<div class="topBar">
    <header align="middle" style="color: White">
      <h1> Invoice Manage System</h1>
      <h2> Search Database</h2>
      <h2 id = "db_name"> <?php echo $to_view; ?> </h2>
    </header>
</div>

<?php
$sql = "SELECT * FROM $to_view";
$result = $conn->query($sql);
echo("<div class = \"container\" style = \"padding : 10px; text-align = middle; \">");
echo("<table id = \"data_table\" class=\"table table-bordered\">");
echo("<thead class=\"thead-light\">");
$first_row = true;
while ($row = $result->fetch_assoc()) {
    if ($first_row) {
        $first_row = false;
        // Output header row from keys.
        echo '<tr>';
        foreach($row as $key => $field) {
            if($to_view === "Invoice" && $_SESSION['manager'] !== true && $key === "Sales"){
                echo '';
            }
            else{
                echo '<th>' . htmlspecialchars($key) . '</th>';
            }
        }

        if($show_DIV === true){echo "<th> Delete </th>";}
        echo '</tr>';
    }
    echo '</thead>';
    echo '<tr>';
    foreach($row as $key => $field) {
        if($to_view === "Invoice" && $_SESSION['manager'] !== true){
            if($_SESSION['user'] === $row["Sales"]){
                if($key === "Sales"){
                echo '';
                }
                else{
                echo '<td>' . htmlspecialchars($field) . '</td>'; 
                }
            }
        }
        else{
            echo '<td>' . htmlspecialchars($field) . '</td>';
        }
    }
 
    if($show_DIV === true){
    echo ("<td>");
     echo "<button name=\"delete\" class=\"btn btn-primary\" type=\"button\"> Delete</button>";
    echo("</td>");
    }
    echo ('</tr>');
}
echo("</table>");
?>
<div>
<button class="btn btn-primary" onclick="location.href='search_db.php'" type="button">
                    Return</button>
</div>
</div>



<?php
$conn->close();
?>
<script>

var deleteButton = document.getElementsByName("delete");
for(var i=0; i<deleteButton.length; i++){
    deleteButton[i].addEventListener('click', function(){ 

        var header = document.getElementById("data_table").rows[0].cells;
        var sql = "Delete From ";
        sql += document.getElementById("db_name").innerHTML;
        sql += " WHERE ";
        for (let i = 0; i < this.parentNode.cellIndex; i++){
            sql += header[i].innerHTML; 
            sql += "='"; 
            sql += document.getElementById("data_table").rows[this.parentNode.parentNode.rowIndex].cells[i].innerHTML;
            sql += "' AND ";
        }
        sql = sql.slice(0, -4);
        sql += ";" ;
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                alert(this.responseText);
                location.reload();
            }
            else if (this.readyState == 4 && this.status !== 200){
                alert(this.responseText);
            }

        }
        xmlhttp.open("GET", "delete_db.php?sql="+sql, true);
        xmlhttp.send();
      });

};


</script>

</body>
</html>
