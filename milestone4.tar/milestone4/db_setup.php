<?php
$servername = "localhost";
$username = "yliu157";
$password = "gdEQz3G7";

$conn = new mysqli($servername, $username, $password);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
else {
 //  echo "Successfully connected to database";
}

$sql = "USE yliu157_1;";
if ($conn->query($sql) === TRUE) {
   // echo "using Database tbiswas2_company";
} else {
    $showDiv = true;
   $db_message =  "Error using  database: " . $conn->error;
}



?>
