<!DOCTYPE html>
<html>
<head>

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</head>
<body>


<?php
require_once('db_setup.php');
session_start();
if($_SESSION['loggedin'] !== true){
    $_SESSION = array();
    session_destroy();
    header("location: ./welcome.html");
    exit;
}
if($_SESSION['manager'] === true){
    $return_url = "manage_function.php";
}
if($_SESSION['manager'] === false){
    $return_url = "sales_function.php";
}

$sql = "USE yliu157_1";
if ($conn->query($sql) === TRUE) {
} else {
   echo "Error using  database: " . $conn->error;
}
// Query:
$id=$id_err='';
$id = $_POST['id'];
$sql = "SELECT * FROM Invoice where Sales= '$id';";

$result = $conn->query($sql);

if($result->num_rows > 0){

?>
   <table class="table table-striped">
      <tr>
         <th>invoice id</th>
         <th>customer id</th>
         <th>Status</th>
         <th>Sales</th>   
          <th>delete</th>   
      
      </tr>
<?php
while($row = $result->fetch_assoc()){
?>
      <tr>
          <td><?php echo $row['Invoice_ID']?></td>
          <td><?php echo $row['Cust_ID']?></td>
          <td><?php echo $row['Status']?></td>
          <td><?php echo $row['Sales']?></td>
          echo '<td><input type="submit" name="deleteItem" value="delete" onclick="delete()" /></td>"';
      </tr>
<?php
}
}
else {
echo "No such sales or sales sell nothing";
}
?>
<?php
function delete(){
$sql='delete from Product where Sales=$id;';
if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
} else {
    echo "Error deleting record: " . $conn->error;
}
}
?>

    </table>

<?php
$conn->close();
?>

</div>

<div class="container" style="width: 400px;">
        <h1 align="middle">search sales</h1>
        <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="POST">
            <div class="form-group <?php echo (!empty($id_err)) ? 'has-error' : ''; ?>">
                <label>Sales ID</label>
                <input type="number" name="id" class="form-control">
        <div class="form-group">
          <div class="row">
      <div class="column">
                    <input type="submit" class="btn btn-primary" value="Submit">
                    </div>
          <div class="form-group">
          <div class="row">
                    <div class="column">
                    <button class="btn btn-primary" 
                        onclick="location.href='./<?php echo $return_url; ?>'" type="button">  
                        Return</button>  
                    </div>  
                    
</body>
</html>