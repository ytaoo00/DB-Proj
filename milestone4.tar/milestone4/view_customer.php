<!DOCTYPE html>
<html>
<head>

<link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" href="main.css">
</head>
<body>



<?php
require_once('db_setup.php');
session_start();
if($_SESSION['loggedin'] !== true){
    $_SESSION = array();
    session_destroy();
    header("location: ./welcome.html");
    exit;
}
$show_DIV = false;
$address_first = false;
if($_SESSION['manager'] === true){
    $show_DIV = true;
}
$sql = "USE yliu157_1";
if ($conn->query($sql) === TRUE) {
   // echo "using Database ";
} else {
   echo "Error using  database: " . $conn->error;
}
// Query:

$str1 = "Select * From Customer WHERE ";
$sql1 = "Select * From Customer WHERE ";
if(!empty($_POST['customer_ID'])){
    $customer_ID = $_POST['customer_ID'];
    if(strlen($sql1) > strlen($str1)){$sql1 .= " AND Customer_ID = \"$customer_ID\" ";}
    else{$sql1 .= " Customer_ID = \"$customer_ID\" ";}
}
if(!empty($_POST['customer_first_name'])){
    $customer_first_name = $_POST['customer_first_name'];
    if(strlen($sql1) > strlen($str1)){$sql1 .= " AND Customer_First_Name = \"$customer_first_name\" ";}
    else{
        $sql1 .= " Customer_First_Name = \"$customer_first_name\" ";
    }
}
if(!empty($_POST['customer_last_name'])){
    $customer_last_name = $_POST['customer_last_name'];
    if(strlen($sql1) > strlen($str1)) {$sql1 .= " AND ";}
    $sql1 .= " Customer_Last_Name = \"$customer_last_name\" ";
}

if(empty($_POST['customer_ID'])&&empty($_POST['customer_first_name'])&&empty($_POST['customer_last_name'])){
    $address_first = true;
}
$str2 = "Select * FROM Contact_Info WHERE ";
$sql2 = "Select * FROM Contact_Info WHERE ";
if($address_first === TRUE){
    if(!empty($_POST['customer_address'])){
        $customer_address = $_POST['customer_address'];
        if(strlen($sql2) > strlen($str2)) {$sql1 .= " AND ";}
        $sql2 .= " Customer_StreetAddress LIKE \"$customer_address%\" ";
    }
    if(!empty($_POST['customer_state'])){
        $customer_state = $_POST['customer_state'];
        if(strlen($sql2) > strlen($str2)) {$sql1 .= " AND ";}
        $sql2 .= " Customer_State LIKE \"$customer_state%\" ";
    }
    if(!empty($_POST['customer_zip'])){
        $customer_zip = $_POST['customer_zip'];
        if(strlen($sql2) > strlen($str2)) {$sql1 .= " AND ";}
        $sql2 .= " Customer_Zip = \"$customer_zip\" ";
    }
    if(!empty($_POST['customer_phone_number'])){
        $customer_phone_number = $_POST['customer_phone_number'];
        if(strlen($sql2) > strlen($str2)) {$sql1 .= " AND ";}
        $sql2 .= " Customer_Phone = \"$customer_phone_number\" ";
    }
}

?>

<div class="topBar">
    <header align="middle" style="color: White">
      <h1> Invoice Manage System</h1>
      <h2> Search Customer</h2>
      <h2 id = "db_name">Customer</h2>
    </header>
</div>



<div class = "container" style = "padding : 10px; text-align = middle; ">
<table id = "data_table" class="table table-bordered\">
<thead class="thead-light">
<tr>
<th>Customer_ID</th>
<th>Customer_First_Name</th>
<th>Customer_Last_Name</th>
<?php  if($show_DIV === true){echo "<th> DELETE </th>";} ?>
</tr>
<?php

if($address_first === true){
    $result2 = $conn->query($sql2);
    while ($row = $result2->fetch_assoc()) {
        $customer_ID = $row['CustomerID'];
        $sql = "Select * From Customer WHERE Customer_ID = \"$customer_ID\"";
        $result3 = $conn->query($sql);
        $row3 = $result3->fetch_assoc();
        echo '<tr>';
        foreach($row3 as $key => $field) {
            echo '<td>' . htmlspecialchars($field) . '</td>'; 
        }
        if($show_DIV === true){
            echo ("<td>");
             echo "<button name=\"delete\" class=\"btn btn-primary\" type=\"button\"> Delete</button>";
            echo("</td>");
        }
        echo '</tr>';
    }
}
else{
    $result1 = $conn->query($sql1);
    while ($row = $result1->fetch_assoc()) {
        echo '<tr>';
        foreach($row as $key => $field) {
            echo '<td>' . htmlspecialchars($field) . '</td>'; 
        }
        if($show_DIV === true){
            echo ("<td>");
             echo "<button name=\"delete\" class=\"btn btn-primary\" type=\"button\"> Delete</button>";
            echo("</td>");
            }
            echo ('</tr>');
    }
}

echo("</table>");
?>
<div>
<button class="btn btn-primary" onclick="location.href='search_customer.php'" type="button">
                    Return</button>
</div>
</div>



<?php
$conn->close();
?>


<script>

var deleteButton = document.getElementsByName("delete");
for(var i=0; i<deleteButton.length; i++){
    deleteButton[i].addEventListener('click', function(){ 
        var header = document.getElementById("data_table").rows[0].cells;
        var sql = "Delete From ";
        sql += document.getElementById("db_name").innerHTML;
        sql += " WHERE ";
        for (let i = 0; i < this.parentNode.cellIndex; i++){
            sql += header[i].innerHTML; 
            sql += "='"; 
            sql += document.getElementById("data_table").rows[this.parentNode.parentNode.rowIndex].cells[i].innerHTML;
            sql += "' AND ";
        }
        sql = sql.slice(0, -4);
        sql += ";" ;
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                alert(this.responseText);
                location.reload();
            }
            else if (this.readyState == 4 && this.status !== 200){
                alert(this.responseText);
            }

        }
        xmlhttp.open("GET", "delete_db.php?sql="+sql, true);
        xmlhttp.send();
      });

};

</script>

</body>
</html>
