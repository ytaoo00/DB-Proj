<?php
require_once("db_setup.php");
session_start();
if($_SESSION['loggedin'] !== true || $_SESSION['manager'] !== true){
    $_SESSION = array();
    session_destroy();
    header("location: ./welcome.html");
    exit;
}

$sql = $_REQUEST["sql"];

$result = $conn->query($sql);

if ($result === TRUE) {
   $db_message =  "Delete Operation Done";
} else {
    $db_message =  "Error: " . $sql . "<br>" . $conn->error;
}

echo $db_message;

?>