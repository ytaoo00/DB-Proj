<?php
session_start();
$_SESSION = array();
session_destroy();
echo
header("location: ./welcome.html");
exit;
?>