<!DOCTYPE html>
<html>
<head>
    <title>Analyzing total Sales</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="main.css">
</head>
<body>

<div class="topBar">
    <header align="middle" style="color: White">
      <h1> Invoice Manage System</h1>
      <h2> Analyzing total Sales</h2>
    </header>
</div>


<?php
require_once('db_setup.php');
$sql = "USE yliu157_1;";
if ($conn->query($sql) === TRUE) {
   // echo "using Database tbiswas2_company";
} else {
   echo "Error using  database: " . $conn->error;
}
session_start();


$err_message = "";
if($_SESSION['loggedin'] !== true){
    $_SESSION = array();
    session_destroy();
    header("location: ./welcome.html");
    exit;
}



?>


<div class = "container" style = "padding : 10px; text-align = middle;">
<table class="table table-bordered">
<thead class="thead-light">
<tr>

<th> Sales </th>
<th> Income </th>
</tr>
</thead>

<?php

if($_SESSION['manager'] === true){

    $return_url = "manage_function.php";
    $sql = "Create Temporary Table T select Sales, Product_Name, SUM(Prod_Quantity)*Product_Price as Income, Product_Price from Include_Product Join Invoice on Invoice_ID = Inv_ID  Join Product on Prod_ID = Product_ID GROUP BY Product_Name,Sales;";
    $result = $conn->query($sql);
    $sql = "Create Temporary Table T2 select Sales, Sum(Income) as Sales_Total_Income from T Group BY Sales;";
    $result = $conn->query($sql);
    $sql1 = "Select * From T2;";
    $result1 = $conn->query($sql1);
    while ($row = $result1->fetch_assoc()) {
        echo '<tr>';
        foreach($row as $key => $field) {
            echo '<td>' . htmlspecialchars($field) . '</td>'; 
        }
        echo '</tr>';
    }
    echo '<tr>';
    echo '<td>';
    $sql2 = "Select Sum(Sales_Total_Income) as Total_Income  from T2;";
    $result2 = $conn->query($sql2);
    $row2 = $result2->fetch_assoc();
    echo ('Total Income');
    echo '</td>';
    echo '<td>';
    $total_income = $row2['Total_Income'];
    echo $total_income;
    echo '</td>';
}
else{

    $return_url = "sales_function.php";
    $username = $_SESSION['user'];
    $sql = "Create Temporary Table T select Sales, Product_Name, SUM(Prod_Quantity)*Product_Price as Income, Product_Price from Include_Product Join Invoice on Invoice_ID = Inv_ID  Join Product on Prod_ID = Product_ID GROUP BY Product_Name,Sales;";
    $result1 = $conn->query($sql);
    $sql1 = "Create Temporary Table T2 select Sales, Sum(Income) as Sales_Total_Income from T Group BY Sales;" ;
    $result1 = $conn->query($sql1);
    $sql2 = "Select * From T2 WHERE Sales like \"$username%\"; ";
    $result2 = $conn->query($sql2);
    while ($row = $result2->fetch_assoc()) {
        echo '<tr>';
        foreach($row as $key => $field) {
            echo '<td>' . htmlspecialchars($field) . '</td>'; 
        }
        echo '</tr>';
    }
}

?>

</table>
<div>
<button class="btn btn-primary" onclick="location.href='./<?php echo $return_url; ?>'" type="button">
              Return</button>
</div>

<?php
$conn->close();
?>
</body>
</html>