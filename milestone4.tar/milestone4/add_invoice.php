<!DOCTYPE html>
<html>
<head>
    <title>Add Invoice</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="main.css">
</head>
<body>


<?php
require_once("db_setup.php");
session_start();
if($_SESSION['loggedin'] !== true){
    $_SESSION = array();
    session_destroy();
    header("location: ./welcome.html");
    exit;
}
$show_sales = false;
$sales_username = "";
if($_SESSION['manager'] === true){
    $return_url = "manage_function.php";
    $show_sales = true;
}
if($_SESSION['manager'] === false){
    $return_url = "sales_function.php";
    $sales_username = $_SESSION['user'];
}

$invoice_ID = $invoice_ID_err = "";
$cust_ID = $customer_ID_err = "";
$product_quanlity=$product_quanlity_err = "";
$product_name=$product_name_err = "";
$sales_err = "";
$status = "";
$db_message = "";
$showDiv = false; 

if($_SERVER["REQUEST_METHOD"] == "POST"){
if(empty($_POST["invoice_ID"])){
    $invoice_ID_err = "Please enter the invoice ID.";
} elseif(!ctype_digit($_POST[invoice_ID])){
    $invoice_ID_err = "Please enter a integer value。." ;
}else{
    $invoice_ID = $_POST["invoice_ID"];
}
if(empty($_POST["customer_ID"])){
    $customer_ID_err = "Please enter the customer ID.";
} elseif(!ctype_digit($_POST["customer_ID"])){
    $customer_ID_err = "Please enter a integer value" ;
}else{
    $cust_ID = $_POST["customer_ID"];
}

if(empty($_POST["product_name"])){
  $product_name_err = "Please enter the product Name.";
}else{
  $product_name = $_POST["product_name"];
}

if(empty($_POST["product_quanlity"])){
  $product_quanlity_err = "Please enter the customer ID.";
} elseif(!ctype_digit($_POST["product_quanlity"])){
  $product_quanlity_err = "Please enter a integer value" ;
}else{
  $product_quanlity = $_POST["product_quanlity"];
}


if(empty($_POST["sales_username"])){
  $sales_err = "Please enter the sales username.";
}else{
  $sales_username = $_POST["sales_username"];
}

if($_POST['status'] === "flagged" ){
    $status = "Flagged";
}
else{
    $status = "Normal";
}

$sql = "USE yliu157_1;";
if ($conn->query($sql) === TRUE) {
   // echo "using Database tbiswas2_company";
} else {
    $showDiv = true;
   $db_message =  "Error using  database: " . $conn->error;
}

// Query:

$sql = "INSERT INTO Invoice values ($invoice_ID , $cust_ID , '$status', '$sales_username');";

$result = $conn->query($sql);

$sql2 = "SELECT Product_ID FROM Product WHERE Product_Name LIKE \"$product_name%\";";

$result2 = $conn->query($sql2);

$row = $result2->fetch_assoc();

$product_ID = $row["Product_ID"];

$sql3 = "INSERT INTO Include_Product values ($product_ID , $invoice_ID , $product_quanlity);";

$result3 = $conn->query($sql3);


if ($result === TRUE && $result3 === TRUE) {
    $showDiv = true;
   $db_message =  "New record created successfully";
} else {
    $showDiv = true;
    $db_message =  "Error: " . $sql . "<br>" . $conn->error;
} 

$conn->close();
}
?>  


<div class="topBar">
    <Header align = "middle" style = "color: White">
      <h1> Invoice Manage System</h1>
      <h2> Add Invoice</h2>
    </Header>

</div>

<div class="container" style="width: 400px;">
    <h1 align="middle">Add Invoice</h1>
    <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="POST">
    <div <?php if ($showDiv===false){?> style="display:none" <?php } ?> class="form-group">
                <p style = "border: 3px solid black; color: red;"><?php echo $db_message?></p>
    </div>
      <div class="form-group <?php echo (!empty($invoice_ID_err)) ? 'has-error' : ''; ?>">
        <label>Invoice ID</label>
        <input type="number" name="invoice_ID" class="form-control">
        <span class="help-block"><?php echo $invoice_ID_err; ?></span>
      </div>
      <div class="form-group <?php echo (!empty($customer_ID_err)) ? 'has-error' : ''; ?>">
        <label>Customer ID</label>
        <input type="number" name="customer_ID" class="form-control">
        <span class="help-block"><?php echo $customer_ID_err; ?></span>
      </div>
      <div class="form-group <?php echo (!empty($product_name_err)) ? 'has-error' : ''; ?>">
        <label>Product Name</label>
        <input type="text" name="product_name" class="form-control">
        <span class="help-block"><?php echo $product_name_err; ?></span>
        <small class = "form-text text-muted">For Demo Purpose, the product include but not limited to TV; Headphone; Monitor; Laptop; Phone; Mouse </small>
      </div>
      <div class="form-group <?php echo (!empty($product_quanlity_err)) ? 'has-error' : ''; ?>">
        <label>Product Quanlity</label>
        <input type="number" name="product_quanlity" class="form-control">
        <span class="help-block"><?php echo $product_quanlity_err; ?></span>
      </div>
      <div class="form-group">
        <label>Status</label>
        <small class = "form-text text-muted">if you leave this option unchecked, the default value in the data base will be normal. </small>
        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="status" id="normal" value="normal">
          <label class="form-check-label" for="normal">
            Normal
          </label>
        </div>
        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="status" id="flagged" value="flagged">
          <label class="form-check-label" for="flagged">
            Flagged
          </label>
        </div>
      </div>

      <?php 
        if($show_sales === true){
          $form_class = "form-group" + (!empty($invoice_ID_err)) ? 'has-error' : '';
            echo("<div class = $form_class>");
            echo ("<label>Sales</label>");
            echo("<input type=\"text\" name=\"sales_username\" value = \"salesman1\" class=\"form-control\">");
            echo("<small class = \"form-text text-muted\">For Demo Purpose, there are only two sales in the database. salesman1 and salesman2 </small>");
            echo("<span class=\"help-block\">$sales_error</span>");
            echo("</div>"); 
        }
        else{
          echo("<div class=\"form-group\">");
          echo("<input type = \"hidden\" name=\"sales_username\" value =\"$sales_username\" class=\"form-control\">");
          echo("</div>");
        }
      ?>


      <div class="form-group">
          <div class="row">
                    <div class="column">
                    <input type="submit" class="btn btn-primary" value="Submit">
                    </div>
                    <div class="column">
                    <button class="btn btn-primary" 
                        onclick="location.href='./<?php echo $return_url; ?>'" type="button">  
                        Return</button>  
                    </div>  
      </div>
    </form>
  </div>

</body>
</html>

