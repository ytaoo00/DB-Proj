<!DOCTYPE html>
<html>

<head>
    <title>Sales Function List</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="main.css">
</head>

<body>
<?php
session_start();
 
if($_SESSION["loggedin"] !== true || $_SESSION["manager"] !== false ){
    $_SESSION = array();
    session_destroy();
    header("location: ./sales_login.php");
    exit;

}
?>
    <ul>
        <li><a href="#home">Home</a></li>
        <li><a href="#add">Add</a></li>
        <li><a href="#search">Search</a></li>
        <li><a href="#analysis">Analysis</a></li>
        <li style="float:right"><a href="logout.php">Logout</a></li>
    </ul>

    <div class="container">
        <div id = "home"></div>
        <div class="centerBlock">
            <p align="middle" style="font-size : 30px;">
                Welcome to the Invoice Manage System. <br />
                As a salesman, you are allowed to do the following operations.
            </p>
        </div>
        <div id = "add">
        <div class="leftBlock">
            <header>
                <h1>Add</h1>
                <h3>Add Function allows you to do the following:</h3>
            </header>
            <hr>
            <p>
                <l1>Add Invoice:</l1><br />
                <l2 style="margin-left: 5%;">This function allows you to add a new invoice</l2>
            </p>
            <button class="btn btn-primary" onclick="location.href='add_invoice.php'" type="button">
                    Add</button>
            <hr>
            <p>
                <l1>Add Customer:</l1><br />
                <l2 style="margin-left: 5%;">This function allows you to add a new customer</l2>
            </p>
            <button class="btn btn-primary" onclick="location.href='add_customer.php'" type="button">
                    Add</button>
        </div>

        <div id = "search"></div>
        <div class="leftBlock">
            <header>
                <h1>Search</h1>
                <h3>Serach Function allows you to do the following:</h3>
            </header>
            <hr>
            <p>
                <l1>Search By Database:</l1><br />
                <l2 style="margin-left: 5%;">This function allows you to view the content in the database you selected.
                </l2>
            </p>
            <button class="btn btn-primary" onclick="location.href='search_db.php'" type="button">
                    Search</button>
            <hr>
            <p>
                <l1>Search By Invoice:</l1><br />
                <l2 style="margin-left: 5%;">This function allows you to search based on the invoice information
                </l2>
            </p>
            <button class="btn btn-primary" onclick="location.href='search_invoice.php'" type="button">
                    Search</button>
            <hr>
            <p>
                <l1>Search By Customer:</l1><br />
                <l2 style="margin-left: 5%;">This function allows you to search based on the Customer
                    information
                </l2>
            </p>
            <button class="btn btn-primary" onclick="location.href='search_customer.php'" type="button">
                    Search</button>
            <hr>
            <p>
                <l1>Search By Product:</l1><br />
                <l2 style="margin-left: 5%;">This function allows you to search based on the Product information
                </l2>
            </p>
            <button class="btn btn-primary" onclick="location.href='search_product.php'" type="button">
                    Search</button>
            <hr>
        </div>




        <div id = "analysis"></div>
        <div class="leftBlock">
            <header>
                <h1>Analysis</h1>
                <h3>Analysis Function allows you to do the following:</h3>
            </header>
            <hr>
            <p>
                <l1>Total Sales</l1><br />
                <l2 style="margin-left: 5%;">This function will output your total sales.</l2>
            </p>
            <button class="btn btn-primary" onclick="location.href='analyze_total_sale.php'" type="button">
                Analysis</button>
            <hr>
            <p>
                <l1>Best Selling product</l1><br />
                <l2 style="margin-left: 5%;">This function will output a list product combined with the number sold by you. </l2>
            </p>
            <button class="btn btn-primary" onclick="location.href='analyze_best_selling.php'" type="button">
                Analysis</button>
            <hr>
        </div>

    </div>

</body>

</html>