<!DOCTYPE html>
<html>
<head>

<link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" href="main.css">
</head>
<body>



<?php
require_once('db_setup.php');
session_start();
if($_SESSION['loggedin'] !== true){
    $_SESSION = array();
    session_destroy();
    header("location: ./welcome.html");
    exit;
}
$show_DIV = false;
$address_first = false;
if($_SESSION['manager'] === true){
    $show_DIV = true;
}
$sql = "USE yliu157_1";
if ($conn->query($sql) === TRUE) {
   // echo "using Database ";
} else {
   echo "Error using  database: " . $conn->error;
}
// Query:

$str1 = "Select * From Product WHERE ";
$sql1 = "Select * From Product WHERE ";
if(!empty($_POST['product_ID'])){
    $product_ID = $_POST['product_ID'];
    if(strlen($sql1) > strlen($str1)) {$sql1 .= " AND ";}
    $sql1 .= " Product_ID = \"$product_ID\" ";
}
if(!empty($_POST['product_price'])){
    $product_price = $_POST['product_price'];
    if(strlen($sql1) > strlen($str1)) {$sql1 .= " AND ";}
    $sql1 .= " Product_Price = \"$product_price\" ";
}
if(!empty($_POST['product_name'])){
    $product_name = $_POST['product_name'];
    if(strlen($sql1) > strlen($str1)) {$sql1 .= " AND ";}
    $sql1 .= " Product_Name LIKE \"$product_name%\" ";
}


?>

<div class="topBar">
    <header align="middle" style="color: White">
      <h1> Invoice Manage System</h1>
      <h2> Search Customer</h2>
      <h2 id = "db_name"> Product </h2>
    </header>
</div>



<div class = "container" style = "padding : 10px; text-align = middle; ">
<table id = "data_table" class="table table-bordered\">
<thead class="thead-light">
<tr>
<th>Product_ID</th>
<th>Product_Price</th>
<th>Product_Name</th>
<?php  if($show_DIV === true){echo "<th> DELETE </th>";} ?>
</tr>
<?php


    $result1 = $conn->query($sql1);
    while ($row = $result1->fetch_assoc()) {
        echo '<tr>';
        foreach($row as $key => $field) {
            echo '<td>' . htmlspecialchars($field) . '</td>'; 
        }
        if($show_DIV === true){
            echo ("<td>");
             echo "<button name=\"delete\" class=\"btn btn-primary\" type=\"button\"> Delete</button>";
            echo("</td>");
        }
    }

echo("</table>");
?>
<div>
<button class="btn btn-primary" onclick="location.href='search_product.php'" type="button">
                    Return</button>
</div>
</div>



<?php
$conn->close();
?>
<script>
deleteButton = document.getElementsByName("delete");
for(var i=0; i<deleteButton.length; i++){
    deleteButton[i].addEventListener('click', function(){ 
        var header = document.getElementById("data_table").rows[0].cells;
        var sql = "Delete From ";
        sql += document.getElementById("db_name").innerHTML;
        sql += " WHERE ";
        for (let i = 0; i < this.parentNode.cellIndex; i++){
            sql += header[i].innerHTML; 
            sql += "='"; 
            sql += document.getElementById("data_table").rows[this.parentNode.parentNode.rowIndex].cells[i].innerHTML;
            sql += "' AND ";
        }
        sql = sql.slice(0, -4);
        sql += ";" ;
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                alert(this.responseText);
                location.reload();
            }
            else if (this.readyState == 4 && this.status !== 200){
                alert(this.responseText);
            }

        }
        xmlhttp.open("GET", "delete_db.php?sql="+sql, true);
        xmlhttp.send();
      });

};

</script>

</body>
</html>
