<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" href="main.css">
</head>
<body>

<?php
require_once('db_setup.php');
$username = $pword = "";
$username_err = $password_err = "";

//check login stats
if($_SERVER["REQUEST_METHOD"] == "POST"){
    if(empty($_POST["username"])){
        $username_err = "Please enter username.";
    } else{
        $username = $_POST["username"];
    }
    if(empty($_POST["password"])){
        $password_err = "Please enter your password.";
    } else{
        $pword = $_POST["password"];
    }
//initialize data base & login verification
    $sql = "USE yliu157_1";
    if ($conn->query($sql) === TRUE) {
    } else {
    echo "Error using  database: " . $conn->error;
    }
    $sql = "SELECT Pword FROM Sales WHERE Username = '$username';";
    $result = $conn->query($sql);
    //echo("numeber of rows is ");
    //echo($result->num_rows);
    /*
    if($result->num_rows > 0){
        echo("username correct");
        $row = $result->fetch_assoc();
        echo $row['Pword'];
    }
    else{
            echo("else");
    echo($result->error);
    }
    */



    $row_number = $result->num_rows ;
    $row = $result->fetch_assoc(); // username is a primary key, safe to do so
    if($row_number == 1){
        if($row['Pword'] == $pword){
            session_start();
            $_SESSION["loggedin"] = true;
            $_SESSION["user"] = $username;
            $_SESSION["manager"] = false;
            header("Location: ./sales_function.php");
        }

        else{
            $password_err = "You have entered the wrong password.";
        }
    }
    else{
        $username_err = "Account with this username does not exist.";
    }
    $conn->close();
}

?>

    <div class="container" style="width: 400px;">
        <h1 align="middle">Sales Login</h1>
        <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="POST">
            <div class="form-group <?php echo (!empty($username_err)) ? 'has-error' : ''; ?>">
                <label>Username</label>
                <input type="text" name="username" class="form-control" value="<?php echo $username; ?>">
                <span class="help-block"><?php echo $username_err; ?></span>
            </div>    
            <div class="form-group <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
                <label>Password</label>
                <input type="password" name="password" class="form-control">
                <span class="help-block"><?php echo $password_err; ?></span>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="column">
                    <input type="submit" class="btn btn-primary" value="Login">
                    </div>
                    <div class="column">
                    <button class="btn btn-primary" 
                        onclick="location.href='welcome.html'" type="button">
                        Return</button>
                    </div>
                </div>
            </div>
        </form>
    </div>


</body>
</html>