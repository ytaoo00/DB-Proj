<!DOCTYPE html>
<html>
<head>
    <title>Add Invoice</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="main.css">
</head>
<body>

<div class="topBar">
    <header align="middle" style="color: White">
      <h1> Invoice Manage System</h1>
      <h2> Search Invoice</h2>
    </header>
</div>


<?php
require_once("db_setup.php");
session_start();
$err_message = "";
if($_SESSION['loggedin'] !== true){
    $_SESSION = array();
    session_destroy();
    header("location: ./welcome.html");
    exit;
}

if($_SESSION['manager'] === true){
    $return_url = "manage_function.php";
    $show_DIV = true;
}
if($_SESSION['manager'] === false){
    $return_url = "sales_function.php";
    $show_DIV = false;
    $username = $_SESSION['user'];
}
/*
if($_SERVER["REQUEST_METHOD"] == "POST"){
    if(empty(isset($_POST['customer_ID']))&&empty(isset($_POST['customer_first_name']))&&empty(isset($_POST['customer_last_name']))
    &&empty(isset($_POST['customer_address']))&&empty(isset($_POST['customer_state']))&&empty(isset($_POST['customer_zip']))
    &&empty(isset($_POST['customer_phone_number']))){
        $showDIV = true;
        $err_message = "Please enter at least one field";
    }
}
*/

?>


<div class="container" style="width: 400px;">
  <h1 align="middle">Search Invoice</h1>
  <h3 align="middle">Enter at least 1 field to start search</h3>
  <form action="view_invoice.php" method="POST">
        <div <?php if ($showDiv===false){?> style="display:none" <?php } ?> class="form-group">
                <p style = "border: 3px solid black; color: red;"><?php echo $db_message?></p>
        </div>
            <div class="form-group <?php echo (!empty($product_ID_err)) ? 'has-error' : ''; ?>">
                <label>Invoice ID</label>
                <input type="number" name="invoice_ID" class="form-control">
            </div>
            <div class="form-group <?php echo (!empty($product_price_err)) ? 'has-error' : ''; ?>">
                <label>Customer ID</label>
                <input type="number" name="customer_ID" class="form-control">
            </div>
            <div class="form-group">
        <label>Status</label>
        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="status" id="normal" value="normal">
          <label class="form-check-label" for="normal">
            Normal
          </label>
        </div>
        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="status" id="flagged" value="flagged">
          <label class="form-check-label" for="flagged">
            Flagged
          </label>
        </div>


            <?php 
        if($show_DIV === true){
          $form_class = "form-group" + (!empty($invoice_ID_err)) ? 'has-error' : '';
            echo("<div class = $form_class>");
            echo ("<label>Sales</label>");
            echo("<input type=\"text\" name=\"username\" class=\"form-control\">");
            echo("<small class = \"form-text text-muted\">For Demo Purpose, there are only two sales in the database. salesman1 and salesman2 </small>");
            echo("</div>"); 
        }
        else{
            echo("<input type=\"hidden\" name=\"username\" value = \"$username\" class=\"form-control\">");
        }
      ?>



           <div class="form-group">
          <div class="row">
                    <div class="column">
                    <input type="submit" class="btn btn-primary" value="Submit">
                    </div>
                    <div class="column">
                    <button class="btn btn-primary" 
                        onclick="location.href='./<?php echo $return_url; ?>'" type="button">  
                        Return</button>  
                    </div>  
         </div>
  </form>
</div>
</body>
</html>